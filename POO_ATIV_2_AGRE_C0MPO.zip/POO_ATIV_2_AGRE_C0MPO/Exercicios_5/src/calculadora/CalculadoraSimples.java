package calculadora;
import javax.swing.JOptionPane; 
public class CalculadoraSimples { 
    public static void main(String[] args) {
        double num1 = 0;         
        double num2 = 0;         
        String operacao = "";         
        double resultado = 0;         
        boolean entradaValida = false; 
        
        while (!entradaValida) {
            try { 
                String input1 = JOptionPane.showInputDialog( 
                    null,  
                    "Digite o primeiro número:",  
                    "Calculadora Simples",  
                    JOptionPane.QUESTION_MESSAGE 
                ); 
                if (input1 == null) {
                    return;
                }
                num1 = Double.parseDouble(input1);
                entradaValida = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(
                    null,
                    "Erro: O primeiro valor digitado não é um número válido.",
                    "Erro de Entrada",  
                    JOptionPane.ERROR_MESSAGE 
                ); 
            } 
        }

        entradaValida = false;
        while (!entradaValida) {
            try {
                String input2 = JOptionPane.showInputDialog(
                    null,
                    "Digite o segundo número:",
                    "Calculadora Simples",  
                    JOptionPane.QUESTION_MESSAGE 
                );                 
                if (input2 == null) {                    
                    return;
                }
                num2 = Double.parseDouble(input2);
                entradaValida = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(
                    null,
                    "Erro: O segundo valor digitado não é um número válido.",  
                    "Erro de Entrada",  
                    JOptionPane.ERROR_MESSAGE 
                ); 
            } 
        }

        String[] opcoes = {"+", "-", "x", "÷"};
        int escolha = JOptionPane.showOptionDialog(
            null, "Escolha a operação:", "Calculadora Simples", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,null, opcoes, opcoes[0]
        );

        if (escolha == -1) {
            return;
        }
        operacao = opcoes[escolha];
        String mensagemResultado = ""; 
 
        switch (operacao) {             case "+": 
                resultado = num1 + num2; 
                mensagemResultado = String.format("%.2f %s %.2f = %.2f", num1, operacao, num2, resultado); 
                break;             case "-": 
                resultado = num1 - num2; 
                mensagemResultado = String.format("%.2f %s %.2f = %.2f", num1, operacao, num2, resultado); 
                break;             case "x": 
                resultado = num1 * num2; 
                mensagemResultado = String.format("%.2f %s %.2f = %.2f", num1, operacao, num2, resultado); 
                break;             case "÷": JOptionPane.showMessageDialog(
                    null,
                    mensagemResultado,
                    "Erro de Cálculo",
                    JOptionPane.ERROR_MESSAGE
                );
                    if (num2 == 0) {
                        mensagemResultado = "Erro: Divisão por zero não permitida!";
                    } else {
                        resultado = num1 / num2;
                        mensagemResultado = String.format("%.2f %s %.2f = %.2f", num1, operacao, num2, resultado);
                    }
                    JOptionPane.showMessageDialog(
                        null,
                        mensagemResultado,
                        "Erro de Cálculo",
                        JOptionPane.ERROR_MESSAGE
                    );
                    return;
                } 
                resultado = num1 / num2; 
                mensagemResultado = String.format("%.2f %s %.2f = %.2f", num1, operacao, num2, resultado); 
                break;
        }
        JOptionPane.showMessageDialog(
            null,
            mensagemResultado,
            "Resultado",
            JOptionPane.INFORMATION_MESSAGE
        );
    }