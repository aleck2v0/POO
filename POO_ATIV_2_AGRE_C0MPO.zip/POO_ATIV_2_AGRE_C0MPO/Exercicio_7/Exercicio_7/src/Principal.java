public class Principal {public static void main(String[] args) { 
         
        Pedido meuPedido = new Pedido(); 
 
        meuPedido.adicionarItem("Teclado", 2, 150.00);         meuPedido.adicionarItem("Mouse", 1, 80.00); 
         
        double totalGeral = meuPedido.valorTotal(); 
         
        System.out.println("---------------------------"); 
        System.out.printf("VALOR TOTAL DO PEDIDO: R$ %.2f\n", totalGeral); 
        System.out.println("---------------------------"); 
    } 
} 