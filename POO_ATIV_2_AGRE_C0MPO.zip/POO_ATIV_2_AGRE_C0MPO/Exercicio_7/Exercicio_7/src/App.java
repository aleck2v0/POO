import java.util.ArrayList; import java.util.List; 
 
class ItemPedido {     
    private String nome;     
    private int quantidade;    
    private double precoUnitario;     
    public ItemPedido(String nome, int quantidade, double precoUnitario) {         
        this.nome = nome;         
        this.quantidade = quantidade;         
        this.precoUnitario = precoUnitario; 
    } 
 
    public double calcularSubtotal() {          
        return quantidade * precoUnitario; 
    } 
     
    public String getNome() {         
        return nome; 
    } 
 
    public int getQuantidade() {         
        return quantidade; 
    } 
} 
 
class Pedido {private List<ItemPedido> itens; 
 
    public Pedido() {         
        this.itens = new ArrayList<>(); 
    } 
 
    public void adicionarItem(String nome, int quantidade, double preco) {
        ItemPedido novoItem = new ItemPedido(nome, quantidade, preco);
        this.itens.add(novoItem);
        System.out.println("Item adicionado: " + nome + " (" + quantidade + "x)");
    }

    public double valorTotal() {
        double total = 0.0;
        
        System.out.println("\n--- DETALHES DO CÁLCULO ---");

        for (ItemPedido item : itens) {
            double subtotal = item.calcularSubtotal();
            System.out.printf("- %s (%dx): R$ %.2f\n", item.getNome(), item.getQuantidade(), subtotal);
            total += subtotal;
        }   
        return total; 
    } 
} 