public class Principal {     public static void main(String[] args) { 
         
        Professor prof1 = new Professor("Dr. Romilton"); 
        Professor prof2 = new Professor("Dra. Ronsagela"); 
 
        Turma tADS = new Turma("ADS-2023"); 
 
        System.out.println("\n### 1ª ASSOCIAÇÃO ###");         
        tADS.setProfessor(prof1);         
        tADS.resumo(); 

        System.out.println("\n### TROCA DO PROFESSOR ###");         
        tADS.setProfessor(prof2); 

        tADS.resumo(); 
    } 
} 

