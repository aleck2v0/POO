public class Professor {     private String nome; 
 
    public Professor(String nome) {         
        this.nome = nome; 
    } 
 
    public String getNome() {         
        return nome; 
    } 
 
    public void setNome(String nome) {         
        this.nome = nome; 
    } 
} 
 
class Turma {     
    private String codigo;     
    private Professor professor; 
 
    public Turma(String codigo) {         
        this.codigo = codigo;         
        this.professor = null; 
    } 
 
    public void setProfessor(Professor p) {         
        this.professor = p; 
        System.out.println("Professor '" + p.getNome() + "' associado à Turma " + this.codigo); 
    } 
 
    public void resumo() { 
        System.out.println("--- Resumo da Turma " + this.codigo + " ---"); 
        System.out.println("Código da Turma: " + this.codigo); 
 
        if (this.professor != null) { 
            System.out.println("Professor(a) Associado(a): " + this.professor.getNome()); 
        } else { 
            System.out.println("Professor(a) Associado(a): NENHUM"); 
        } 
        System.out.println("------------------------------------"); 
    } 
} 
